package Pages;

import Base.Base_class;

public class Nextpage extends Base_class{

	
}

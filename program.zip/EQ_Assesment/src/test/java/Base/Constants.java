package Base;

public class Constants {
	public static final String browser = "chrome";
	public static final String url = "https://eqcare.com/en/contact-us/support";
	
}

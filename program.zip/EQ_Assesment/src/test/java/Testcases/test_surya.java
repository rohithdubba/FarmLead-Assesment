package Testcases;




	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.Test;

	public class test_surya {
		WebDriver driver  ;
		@Test
		public  void formFill(){
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://eqcare.com/en/contact-us/support");
			
//			driver.navigate().to("https://eqcare.com/en/contact-us/support");
			
			driver.findElement(By.xpath("//button[text()='Got it']")).click();
//			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
//			WebElement ele = driver.findElement(By.xpath("//*[text()='Send us a message']"));
//			
//			js.executeScript("arguments[0].scrollIntoView();", ele);
////			js.executeScript("arguments[0].click();", ele);
			
			driver.findElement(By.xpath("//input[@placeholder= 'First Name']")).sendKeys("Rohith");
			driver.findElement(By.xpath("//input[@placeholder= 'Last Name']")).sendKeys("Dubba");
			driver.findElement(By.xpath("//input[@placeholder= 'Phone Number']")).sendKeys("88888888888");
			driver.findElement(By.xpath("//input[@placeholder= 'Email address']")).sendKeys("rdas@gmail.com");
			driver.findElement(By.xpath("//select/option[contains(text(), 'Alberta')]")).click();
			driver.findElement(By.xpath("//input[@placeholder= 'Please enter your city']")).sendKeys("toronto");
			driver.findElement(By.xpath("//div/textarea")).sendKeys("this is about care");
			driver.findElement(By.xpath("//button[contains(text(),'Contact Support')]")).click();
			/*driver.quit();*/
		
		}
		 

	}


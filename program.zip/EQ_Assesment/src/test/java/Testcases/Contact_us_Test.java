package Testcases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.Base_class;
import Pages.Contactus_page;
import Pages.Nextpage;

public class Contact_us_Test extends Base_class 
{

	Contactus_page obj;

	@BeforeMethod
	public void init()
	{
		initialization();
		obj= new Contactus_page();
	}
	
	
	@Test
	public void pagevalidation()
	{
		obj.page_validation();
	}

		
	
	
	@Test
	public void contact_form_validation() throws InterruptedException
	{
		try {
			
		obj.form_submssion_withdata();
		String expct_confirm_msg="Your message was sent.";
		System.out.println("the expected msg is "+expct_confirm_msg);
		WebElement msg=driver.findElement(By.xpath("//h3[contains(text(),'Your message was sent.')]"));		
		String act_cnfirm_msg=	msg.getText();
		System.out.println("the actual msg is "+act_cnfirm_msg);
		Assert.assertEquals(act_cnfirm_msg, expct_confirm_msg,"Assertion passed");
	
		
		System.out.println("successfully submitted the contact_us_support form");	
		
		}
		catch(Exception e)
		{
			
			
			obj.form_submssion_withoutdata();
			System.out.println("successfully validated  error messages");	
		}
					
	}
	}
			
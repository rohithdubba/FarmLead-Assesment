package Testcases;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import Base.Base_class;
import Pages.Contactus_page;
import Pages.Nextpage;
public class Backup_Contactuspage extends Base_class{ 
	
	

	

		Contactus_page obj;

		@BeforeMethod
		public void init()
		{
			initialization();
			obj= new Contactus_page();
		}
		
		
		@Test
		public void pagevalidation()
		{
			obj.page_validation();
		}
		@Test
		public void Contact_form_Test() throws InterruptedException
		{
			
		
			obj.form_submssion();
			
			
			
			String expct_confirm_msg="Your message was sent.";
			WebElement msg;
			try
			{
				 msg=driver.findElement(By.xpath("//h3[contains(text(),'Your message was sent.')]"));
					boolean flag=	msg.isDisplayed();
					String act_cnfirm_msg=	msg.getText();
					Assert.assertEquals(act_cnfirm_msg, expct_confirm_msg);
					System.out.println("the actual msg is "+act_cnfirm_msg);
					System.out.println("the expected msg is "+expct_confirm_msg);
			}
			catch(Exception e){
				try {
					WebElement Fname_error=driver.findElement(By.xpath("//p[contains(text(),'The first name field is required')]"));
					if(Fname_error.isDisplayed())
					{
						Assert.assertEquals(Fname_error.getText(),"The first name field is required");
						System.out.println("The first name field error message test case passed");
					}
					WebElement Lname_error=driver.findElement(By.xpath("//p[contains(text(),'The last name field is required')]"));
					if(Lname_error.isDisplayed())
					{
						Assert.assertEquals(Lname_error.getText(),"The last name field is required");
						System.out.println("The last name field error message test case passed");
					}
					WebElement Email_error=driver.findElement(By.xpath("//p[contains(text(),'The work email field is required')]"));
					
					if(Email_error.isDisplayed())
					{
						Assert.assertEquals(Email_error.getText(),"The work email field is required");
						System.out.println("The email field error message test case passed");
					}
					
					WebElement Province_error=driver.findElement(By.xpath("//p[contains(text(),'Please select a province')]"));
					
					if(Province_error.isDisplayed())
					{
						Assert.assertEquals(Province_error.getText(),"Please select a province");
						System.out.println("The province field error message test case passed");
					}
					WebElement Inquiry_error=driver.findElement(By.xpath("//p[contains(text(),'Please tell us a bit about your inquiry')]"));
					if(Inquiry_error.isDisplayed())
					{
						Assert.assertEquals(Inquiry_error.getText(),"Please tell us a bit about your inquiry");
						System.out.println("The Inquiry field error message test case passed");
					}
				}
				
				catch(Exception f)
				{	
					try
					{
						WebElement Lname_error=driver.findElement(By.xpath("//p[contains(text(),'The last name field is required')]"));
						if(Lname_error.isDisplayed())
						{
							Assert.assertEquals(Lname_error.getText(),"The last name field is required");
						}
					}
					catch(Exception g)
					{	
						try {
							
							WebElement Email_error=driver.findElement(By.xpath("//p[contains(text(),'The work email field is required')]"));
							
							if(Email_error.isDisplayed())
							{
								Assert.assertEquals(Email_error.getText(),"The work email field is required");
							}
							
							
						  }
						catch(Exception h)
						{
							
							try
							{
								WebElement Province_error=driver.findElement(By.xpath("//p[contains(text(),'Please select a province')]"));
							
								if(Province_error.isDisplayed())
								{
									Assert.assertEquals(Province_error.getText(),"Please select a province");
								}
							}
						
							catch(Exception i)
							{
								try
								{
								WebElement Inquiry_error=driver.findElement(By.xpath("//p[contains(text(),'Please tell us a bit about your inquiry')]"));
								if(Inquiry_error.isDisplayed())
								{
									Assert.assertEquals(Inquiry_error.getText(),"Please tell us a bit about your inquiry");
								}

								}
								catch(Exception j)
								{
									System.out.println("all conditions checked");
								}
							}
					
						
						}}}}}}
			
					
					
					
					
					
					
					
				
		
			
		
		
	



